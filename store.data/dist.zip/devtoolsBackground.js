var panels = chrome && chrome.devtools && chrome.devtools.panels;
panels.create('JSON-RPC Viewer', 'images/get_started16.png', 'panel.html');
